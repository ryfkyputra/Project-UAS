import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MenuBantuan here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MenuBantuan extends Menu
{

    /**
     * Constructor for objects of class MenuBantuan.
     * 
     */
    public MenuBantuan()
    {
    }
}
